from django.apps import AppConfig


class LogReggConfig(AppConfig):
    name = 'log_regg'
