from django.db import models

# Create your models here.
class ShowManager(models.Manager):
    def basic_validator(self, postData):
        errors = {}
        #add keys and values to error dictionary for each invalid field
        print("postData: ", postData)
        if len(postData["network"])<1:
            errors["network"] = "network input too short"

        print("errors:  ",errors)
        return errors


class Show(models.Model):
    title = models.CharField(max_length = 255)
    network = models.CharField(max_length = 255)
    release_date = models.DateTimeField()
    desc = models.TextField()
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)
    objects = ShowManager()

    def releasedate(self):
        return self.release_date.strftime('%B %d'+','+' %Y')

    def edit_date(self):
        return self.release_date.strftime("%Y-%m-%d")