from django.apps import AppConfig


class AooksAuthorsAppConfig(AppConfig):
    name = 'aooks_authors_app'
